import {languages, supportedLanguage, translate} from './i18n.mjs';
import * as catalog from './catalog.mjs';
import {normalize,dayKey,matchesLesson,score,makePlan,reviewDate,readiness} from './engine.mjs';
const paths={
 home:'M3 10 12 3l9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z',path:'M4 17a2 2 0 1 0 4 0 2 2 0 0 0-4 0Zm12-10a2 2 0 1 0 4 0 2 2 0 0 0-4 0ZM6 15v-4a4 4 0 0 1 4-4h6m2 2v4a4 4 0 0 1-4 4H8',book:'M12 6v15m0-15C8 3 5 3 2 4v14c4-1 7 0 10 3 3-3 6-4 10-3V4c-3-1-6-1-10 2Z',pen:'m4 16-1 5 5-1L21 7l-4-4zm11-11 4 4',stack:'m3 8 9-5 9 5-9 5zm0 4 9 5 9-5M3 16l9 5 9-5',file:'M6 3h8l4 4v14H6zm8 0v5h4M9 12h6m-6 4h6',test:'M5 4h14v17H5zm4 5 1 1 2-2m1 2h3m-7 5 1 1 2-2m1 2h3',mic:'M9 5a3 3 0 0 1 6 0v7a3 3 0 0 1-6 0zm-3 6v1a6 6 0 0 0 12 0v-1m-6 7v4m-3 0h6',again:'M20 11a8 8 0 1 0-2 7m2-13v6h-6',spark:'m12 2 2.5 7.5L22 12l-7.5 2.5L12 22l-2.5-7.5L2 12l7.5-2.5Z',chart:'M3 3v18h18M8 17v-4m5 4V9m5 8V5',bell:'M5 17h14l-2-3V9a5 5 0 0 0-10 0v5zm5 3a2 2 0 0 0 4 0',settings:'M4 7h16M4 17h16M9 4v6m6 4v6',moon:'M20 15a8.5 8.5 0 0 1-11-11 8.5 8.5 0 1 0 11 11Z',sun:'M12 4V2m0 20v-2M4 12H2m20 0h-2M6 6 4 4m16 16-2-2m0-12 2-2M4 20l2-2m10-6a4 4 0 1 1-8 0 4 4 0 0 1 8 0Z',arrow:'M19 12H5m6-6-6 6 6 6',chevron:'m15 6-6 6 6 6',menu:'M3 6h18M3 12h18M3 18h18',clock:'M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Zm-9-5v6l4 2',check:'m5 12 4 4L19 6',target:'M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0Zm-5 0a5 5 0 1 1-10 0 5 5 0 0 1 10 0Z',calendar:'M4 6h16v15H4zm0 4h16M8 3v6m8-6v6',download:'M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5',search:'M16 10a6 6 0 1 1-12 0 6 6 0 0 1 12 0Zm-2 5 6 6',close:'m6 6 12 12M18 6 6 18',lock:'M5 10h14v11H5zm3 0V6a4 4 0 0 1 8 0v4'
};
const icon=(name,size=19)=>`<svg class="icon-${name}" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${paths[name]??paths.file}"/></svg>`;
const nav=[
 ['رحلة الاستعداد',[['home','الرئيسية','home'],['path','مساري','path'],['education','علوم التربية','book'],['subject','التخصص','pen'],['didactics','الديداكتيك','stack']]],
 ['الموارد والتدريب',[['library','المكتبة الرقمية','book'],['archive','الامتحانات السابقة','file'],['lab','مختبر الاختبارات','test'],['oral','أستعد للشفوي','mic'],['errors','دفتر أخطائي','again']]],
 ['أدواتي',[['guide','مرشدي نحو النجاح','spark'],['stats','إحصائياتي','chart'],['notices','الإعلانات الرسمية','bell'],['settings','الإعدادات','settings']]]
];
const links=Object.fromEntries(nav.flatMap(([,group])=>group.map(([id,label,ic])=>[id,{label,ic}])));
const stations=[
 ['فهم المباراة والتوصيف','راجع إعلان الدورة ومكونات الاختبار.','notices','15 د'],
 ['الاختبار التشخيصي','اكتشف المحاور التي تحتاج إلى وقت أكثر.','diagnostic','10 د'],
 ['أساسيات علوم التربية','راجع التعلم والتقويم والتدريس الفارقي.','education','68 د'],
 ['التخصص العلمي والمعرفي','اشتغل على المحتوى المتاح في مسارك.','subject','حسب المسار'],
 ['الديداكتيك','اربط الهدف بالنشاط والتقويم.','didactics','64 د'],
 ['الوضعيات المهنية','حل وضعيات التدبير والمعالجة.','practice','10 د'],
 ['الامتحانات السابقة','اطلع على حالة أرشيف المواضيع الأصلية.','archive','حسب الأرشيف'],
 ['المحاكاة الشاملة','اختبر إدارة الوقت في تدريب مصغر.','simulation','12 د'],
 ['التحضير للشفوي','حضّر جوابك وراجعه بشبكة إرشادية.','oral','7 د'],
 ['المراجعة النهائية','استرجع الأخطاء والبطاقات المستحقة.','errors','15 د']
];
const main=document.querySelector('#main'), modal=document.querySelector('#modal');
const storage='tamayouz-state-v1';
const languageStorage='tamayouz-interface-language';
let language='ar';
try {language=supportedLanguage(localStorage.getItem(languageStorage));}catch{}
const msg=value=>translate(language,value);
const blank=()=>({profile:null,completed:{},attempts:[],review:{},saved:[],queued:[],finished:{},active:null,reading:{},oral:{},theme:'light',palette:'royal'});
function readLocal(key) {
 try {return {...blank(),...JSON.parse(localStorage.getItem(key)||'{}')};}
 catch {return blank();}
}
let syncDelay=null,syncSequence=0;
let state=readLocal(storage), session=null, serverEnabled=false, cloudVersion=0, syncTail=Promise.resolve(), syncBlocked=false, pendingLocal=false, storeKey=storage;
let data={...catalog}, byLesson={}, byQuestion={}, bySource={}, byTrack={}, byCycle={};
let route='home', arg='', mobile=false, toastTimer, quizTimer, oralTimer, pdfCleanup;
const index=list=>Object.fromEntries(list.map(item=>[item.id,item]));
function reindex(){byLesson=index(data.lessons);byQuestion=index(data.questions);bySource=index(data.sources);byTrack=index(data.tracks);byCycle=index(data.cycles);}
reindex();
const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c]);
const safeUrl=value=>{
 if(typeof value!=='string')return '';
 if(/^\.\/[a-z0-9_-]+\.pdf$/i.test(value))return value;
 try {const url=new URL(value);return url.protocol==='https:'?url.href:'';}catch{return '';}
};
const fmt=value=>new Intl.NumberFormat(languages[language].tag,{maximumFractionDigits:2}).format(value);
const dateLabel=value=>value?new Intl.DateTimeFormat(languages[language].tag,{day:'numeric',month:'short',timeZone:'Africa/Casablanca'}).format(new Date(value+'T12:00:00Z')):'—';
const localized=value=>esc(msg(value));
function languageOptions(){
 return Object.entries(languages).map(([code,locale])=>`<option value="${code}" lang="${code}" ${code===language?'selected':''}>${locale.label}</option>`).join('');
}
function applyLanguage(){
 const root=document.documentElement;
 root.lang=language;
 root.dir=languages[language].direction;
 document.title=msg('أكاديمية التميز · الاستعداد لمباراة التعليم');
 document.querySelector('meta[name="description"]').content=msg('مسار مغربي منظم للاستعداد لمباراة التعليم، مع التشخيص والدروس والمكتبة والتدريب.');
 for(const node of document.querySelectorAll('[data-message]'))node.textContent=msg(node.dataset.message);
 for(const node of document.querySelectorAll('[data-message-label]'))node.setAttribute('aria-label',msg(node.dataset.messageLabel));
}
const go=id=>{location.hash=id;};
const action=(label,action,style='',ic='')=>`<button type="button" class="btn ${style}" data-action="${action}">${ic?icon(ic,17):''}${label}</button>`;
const link=(label,target,style='',ic='')=>`<a class="btn ${style}" href="#${target}">${ic?icon(ic,17):''}${label}</a>`;
const outside=(label,url,style='secondary slim',ic='')=>safeUrl(url)?`<a class="btn ${style}" href="${esc(safeUrl(url))}" target="_blank" rel="noopener">${ic?icon(ic,16):''}${label}</a>`:'';
const downloadPdf=(url)=>safeUrl(url)?`<a class="btn secondary slim" href="${esc(safeUrl(url))}" ${url.startsWith('./')?'download':'target="_blank" rel="noopener"'}>${icon('download',16)} ${msg("تحميل PDF")}</a>`:'';
const badge=(label,color='')=>`<span class="badge ${color}">${localized(label)}</span>`;
const tile=(ic,tone='')=>`<span class="tile ${tone}">${icon(ic,20)}</span>`;
const progress=p=>`<div class="bar" role="progressbar" aria-label="${msg("نسبة الإنجاز")}" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${p}"><i style="width:${p}%"></i></div>`;
const head=(title,summary='',right='')=>`<header class="page-head"><div><span class="eyebrow">${msg("أكاديمية التميز")}</span><h1>${title}</h1>${summary?`<p>${summary}</p>`:''}</div>${right}</header>`;
const empty=(title,body,ic='book',right='')=>`<div class="card empty">${tile(ic)}<h3>${title}</h3><p>${body}</p>${right?`<div class="section">${right}</div>`:''}</div>`;
const select=(name,label,items,value='',extra='')=>`<label class="field">${label}<select name="${name}" ${extra}>${items.map(([id,title])=>`<option value="${esc(id)}" ${String(id)===String(value)?'selected':''}>${localized(title)}</option>`).join('')}</select></label>`;
const field=(name,label,type,value,extra='')=>`<label class="field">${label}<input name="${name}" type="${type}" value="${esc(value)}" ${extra}></label>`;
const submit=label=>`<button type="submit" class="btn">${label} ${icon('arrow',17)}</button>`;
function toast(message){const node=document.querySelector('#toast');node.textContent=msg(message);clearTimeout(toastTimer);toastTimer=setTimeout(()=>node.textContent='',3600);}
function applyTheme(){document.documentElement.dataset.theme=state.theme;document.documentElement.dataset.palette=state.palette;}
function save(){
 try {localStorage.setItem(storeKey,JSON.stringify(state));}
 catch {toast(msg("تعذر الحفظ على هذا الجهاز. صدّر بياناتك من الإعدادات."));}
 if(!session||syncBlocked)return;
 const actor=session.id;
 pendingLocal=true;
 try{localStorage.setItem(storeKey+'-unsynced',JSON.stringify({version:cloudVersion}));}catch{}
 clearTimeout(syncDelay);
 syncDelay=setTimeout(()=>flushSync(actor),300);
}
function flushSync(actor=session?.id){
 clearTimeout(syncDelay);syncDelay=null;
 if(!actor||!pendingLocal||syncBlocked)return syncTail;
 const snapshot=structuredClone(state), sequence=++syncSequence;
 syncTail=syncTail.catch(()=>{}).then(async()=>{
  if(session?.id!==actor||syncBlocked)return;
  try {
   const result=await api('/state',{method:'PUT',body:{version:cloudVersion,state:snapshot}});
   cloudVersion=result.version;
   if(sequence===syncSequence&&syncDelay===null){pendingLocal=false;try{localStorage.removeItem(storeKey+'-unsynced');}catch{}}
   else {try{localStorage.setItem(storeKey+'-unsynced',JSON.stringify({version:cloudVersion}));}catch{}}
  }catch(error){if(error.status===409){syncBlocked=true;toast(msg("تغيرت نسخة الحساب في جهاز آخر. صدّر نسخة جهازك ثم أعد تسجيل الدخول."));}else toast(msg("حُفظ التقدم محليا. تعذرت مزامنة الحساب الآن."));}
 });
 return syncTail;
}
async function api(path,opts={}){
 const r=await fetch('./api'+path,{method:opts.method??'GET',headers:opts.body?{'Content-Type':'application/json'}:{},body:opts.body?JSON.stringify(opts.body):undefined,cache:'no-store'});
 if(!r.headers.get('content-type')?.includes('application/json'))throw Error(msg("الخادم غير متاح"));
 const body=await r.json();if(!r.ok){const e=Error(body.error??'تعذر إتمام العملية');e.status=r.status;throw e;}return body;
}
function routeState(){const hash=location.hash.slice(1).split('/');route=hash[0]||'home';arg=hash[1]||'';}
function showMenu(value){mobile=value;document.querySelector('#sidebar').classList.toggle('open',value);document.querySelector('#overlay').hidden=!value;
 const menu=document.querySelector('#menu');
 menu.setAttribute('aria-expanded',String(value));
 menu.dataset.messageLabel=value?'إغلاق القائمة':'فتح القائمة';
 menu.setAttribute('aria-label',msg(menu.dataset.messageLabel));}
const track=()=>byTrack[state.profile?.track];
const cycle=()=>byCycle[track()?.cycle]??data.cycles[0];
const available=()=>data.lessons.filter(item=>matchesLesson(item,track()));
const exams=()=>cycle()?.tables?.[track()?.level==='primary'?track().subject:'secondary']??[];
const latest=(kind)=>state.attempts.find(item=>item.kind===kind && item.track===(track()?.id??null));
const planned=()=>{
 const w=Object.fromEntries(Object.keys(data.domains).map(id=>[id,exams().filter(item=>item.domain===id).reduce((acc,item)=>acc+item.weight,0)||1]));
 const diagnostic=latest('diagnostic'), simulation=latest('simulation');
 const signal=simulation&&diagnostic?{by:{...diagnostic.by,...simulation.by}}:simulation??diagnostic;
 return makePlan(available(),state.profile,signal,state.completed,w);
};
function stats(){
 const lessons=available(), done=lessons.filter(l=>state.completed[l.id]);
 const coverage=lessons.length?Math.round(done.length*100/lessons.length):0;
 const attempts=state.attempts.filter(a=>a.track===(track()?.id??null));
 const avg=attempts.length?Math.round(attempts.reduce((sum,a)=>sum+a.percent,0)/attempts.length):0;
 const days=new Set([...done.map(l=>state.completed[l.id]),...attempts.map(a=>a.date)].filter(d=>d>=reviewDate(-6)&&d<=dayKey())).size;
 const tested=new Set(attempts.flatMap(a=>a.items.filter(i=>i.right).map(i=>i.lesson))).size;
 return {done,coverage,attempts,avg,days,index:readiness({coverage,accuracy:avg,simulation:latest('simulation')?.percent??0,regularity:days*100/7,mastery:lessons.length?Math.min(100,tested*100/lessons.length):0}),minutes:done.reduce((sum,l)=>sum+l.minutes,0)+Math.round(attempts.reduce((sum,a)=>sum+a.seconds,0)/60)};
}
function stationDone(i){
 if(i===0)return state.finished.rules;
 if(i===1)return !!latest('diagnostic');
 if(i===2||i===3||i===4){const d=['education','subject','didactics'][i-2];const ls=available().filter(l=>l.domain===d);return ls.length>0&&ls.every(l=>state.completed[l.id]);}
 if(i===5)return !!latest('practice');
 if(i===7)return !!latest('simulation');
 if(i===8)return Object.values(state.oral).some(item=>item.complete);
 if(i===9)return state.finished.final;
 return false;
}
function nextStage(){
 const i=[0,1,2,3,4,5,7,8,9].find(n=>!stationDone(n)&&(n!==3||available().some(l=>l.domain==='subject')));
 return i===undefined?null:stations[i];
}
function stationTarget(dest){
 if(dest==='diagnostic'||dest==='simulation'||dest==='practice')return 'lab/'+dest;
 return dest;
}
function row(title,summary,dest,indexValue,done=false){
 return `<a class="path-row" href="#${dest}"><span class="num ${done?'done':''}">${done?icon('check',16):indexValue}</span><span><strong dir="auto">${localized(title)}</strong><small dir="auto">${localized(summary)}</small></span><span class="end">${icon('chevron',16)}</span></a>`;
}
function bookCard(item){
 const inLib=state.saved.includes(item.id), inPlan=state.queued.includes(item.id);
 return `<article class="card book-card"><div class="book-cover">${icon(item.kind.includes('كتاب')?'book':'file')}${badge(item.priority,item.priority==='أساسي'?'gold':'')}</div><div class="tags">${badge(item.kind,'neutral')}${badge(item.lang,'neutral')}</div><h3 dir="auto">${esc(item.title)}</h3><p dir="auto">${localized(item.summary)}</p><p class="small" dir="auto">${esc(item.author?item.author+' · ':'')}${localized(item.publisher)} · ${item.year?esc(item.year):msg("دون تاريخ نشر محدد")}${item.pages?' · '+fmt(item.pages)+msg(" صفحة"):''}${item.minutes?' · '+fmt(item.minutes)+msg(" د"):''}</p><div class="actions">${item.pdf?action(msg("اقرأ الآن"),'pdf/'+item.id,'slim','book'):''}${item.pdf?downloadPdf(item.pdf):''}${outside(msg("المصدر"),item.url)}${action(msg("بيانات المرجع"),'source/'+item.id,'secondary slim')}</div><div class="actions">${action(inLib?msg("أزل من مكتبتي"):msg("أضف إلى مكتبتي"),'favorite/'+item.id,'secondary slim')}${action(inPlan?msg("أزل من خطتي"):msg("أضف إلى الخطة"),'queue/'+item.id,'secondary slim')}</div></article>`;
}
function home(){
 const st=stats(), t=track(), next=nextStage(), c=cycle();
 const deadline=state.profile?.examDate||c?.writtenDate;
 const remaining=deadline?Math.max(0,Math.round((Date.parse(deadline)-Date.parse(dayKey()))/86400000)):null;
 const today=state.profile?planned()[0]:null;
 const metrics=[['target',msg("نسبة إنجاز الدروس"),st.coverage+'%',''],['book',msg("الدروس المكتملة"),st.done.length,'green'],['test',msg("الاختبارات المنجزة"),st.attempts.length,'violet'],['calendar',msg("الأيام قبل الكتابي"),remaining??'—','gold']];
 const jobs=t?((today?.items??[]).slice(0,3).map(id=>[byLesson[id].title,byLesson[id].minutes+msg(" دقيقة"),'lesson/'+id,'book'])):[[msg("حدد السلك والتخصص"),msg("أنشئ خطة تناسب وقتك"),'setup','path'],[msg("اجتز التشخيص الأولي"),msg("اكتشف أولويات المراجعة"),'lab/diagnostic','target'],[msg("اطلع على إعلان الدورة"),msg("المواعيد ومكونات الاختبار"),'notices','calendar']];
 if(t&&!jobs.length)jobs.push([msg("راجع دفتر أخطائك"),msg("استرجع المفاهيم التي تحتاج إلى تثبيت"),'errors','again']);
 return `<section class="hero"><img class="hero-art" src="./assets/academy.svg" alt=""><div class="hero-copy"><span class="eyebrow"><i class="dot"></i> ${msg("رحلة الاستعداد لمباراة التعليم · المغرب")}</span><h1>${t?msg("مرحبا")+(state.profile.name?(language==='ar'?'، ':', ')+esc(state.profile.name):''):msg("أكاديمية التميز")}</h1><p>${t?localized(data.levels[t.level])+' · '+localized(t.title):msg("من أول خطوة في الاستعداد... إلى أعلى درجات الجاهزية للمباراة.")}</p><div class="actions">${link(t?msg("تابع الاستعداد"):msg("ابدأ مسار الاستعداد"),t?(next?stationTarget(next[2]):'path'):'setup','gold','arrow')}${link(msg("استكشف المكتبة"),'library','ghost','book')}</div></div></section>
 <div class="metrics">${metrics.map(([ic,label,num,tone])=>`<div class="metric">${tile(ic,tone)}<div><strong>${esc(num)}</strong><small>${label}</small></div></div>`).join('')}</div>
 <div class="dash"><div class="stack"><section class="card"><div class="card-head"><div><h2>${msg("خريطة رحلتك")}</h2><small>${msg("عشر محطات من فهم المباراة إلى المراجعة النهائية")}</small></div><a class="mini-link" href="#path">${msg("عرض المسار")} ${icon('arrow',15)}</a></div>${stations.slice(0,4).map(([title,desc,dest],i)=>row(title,desc,stationTarget(dest),String(i+1).padStart(2,'0'),stationDone(i))).join('')}</section>
 <section class="card"><div class="card-head"><div><h2>${msg("آخر اختبار")}</h2><small>${msg("يظهر الأداء بعد إنهاء أول اختبار")}</small></div><a class="mini-link" href="#lab">${msg("المختبر")}</a></div>${st.attempts[0]?row(quizTitle(st.attempts[0].kind),st.attempts[0].percent+'%','result/'+st.attempts[0].id,icon('test',15)):`<p>${msg("ابدأ بالتشخيص للحصول على أول تحليل حسب المجالات.")}</p>`}</section></div>
 <div class="stack"><section class="card"><div class="card-head"><div><h2>${msg("مهام اليوم")}</h2><small>${today?fmt(today.minutes)+msg(" دقيقة من المراجعة المخططة"):msg("خطوات عملية لبدء الاستعداد")}</small></div>${tile('calendar','green')}</div>${jobs.map(([title,desc,dest,ic])=>row(title,desc,dest,icon(ic,15))).join('')}</section>
 <section class="card"><div class="card-head"><div><h2>${msg("أحدث إعلان رسمي")}</h2><small>${msg("دورة نونبر 2026")}</small></div>${tile('bell','gold')}</div><p>${msg("اطلع على الإعلان والملحق الخاص بتعديل المقاعد.")}</p><div class="actions section">${link(msg("عرض الإعلان"),'notices','secondary slim','arrow')}</div></section></div></div>
 <section class="section"><div class="card-head"><h2>${msg("مراجع مقترحة للبداية")}</h2><a class="mini-link" href="#library">${msg("كل المراجع")} ${icon('arrow',15)}</a></div><div class="grid">${['recap','psych','roadmap'].filter(id=>bySource[id]).map(id=>bookCard(bySource[id])).join('')}</div></section>`;
}
function setup(){
 const p=state.profile??{}, t=track();
 return head(msg("خطط لاستعدادك"),msg("اختر المسار والوقت المتاح. يمكنك تعديلهما بعد التشخيص."))+`<form class="card form study" id="setup"><div class="form-grid">
 ${field('name',msg("اسمك الأول، اختياري"),'text',p.name,'maxlength="60" autocomplete="given-name"')}
 ${select('level',msg("السلك"),Object.entries(data.levels),t?.level??'primary')}
 <div id="subjectField">${trackSelect(t?.level??'primary',t?.id)}</div>
 ${select('baseline',msg("مستواك الحالي"),['مبتدئ','متوسط','متقدم'].map(v=>[v,v]),p.baseline??'مبتدئ')}
 ${field('minutes',msg("الوقت اليومي بالدقائق"),'number',p.minutes??45,'required min="15" max="480"')}
 ${select('days',msg("مدة الخطة"),[[15,msg("15 يوما")],[30,msg("30 يوما")],[60,msg("60 يوما")],[90,msg("90 يوما")],['custom',msg("حسب التاريخ المحدد")]],p.custom?'custom':p.days??30)}
 ${field('examDate',msg("تاريخ الاختبار، للخطة المخصصة"),'date',p.examDate??cycle()?.writtenDate)}
 ${select('preference',msg("طريقة التعلم المفضلة"),['الجمع بينها','الكتب والمراجع','الملخصات','الاختبارات'].map(v=>[v,v]),p.preference??'الجمع بينها')}
 </div><div class="notice">${msg("تستند المكونات والمعاملات إلى إعلان الدورة. توضح صفحة التخصص مدى توفر دروسه الخاصة.")}</div><div class="actions">${submit(msg("احفظ المسار وابدأ التشخيص"))}</div></form>`;
}
function trackSelect(level,current){return select('track',msg("التخصص"),data.tracks.filter(item=>item.level===level).map(item=>[item.id,item.title]),current);}
function path(){
 const st=stats(), p=state.profile, plan=planned();
 return head(msg("مساري الشخصي"),msg("ابدأ بالمحطة الموصى بها، وتصفح باقي المحطات في أي وقت."),link(p?msg("تعديل المسار"):msg("اختر مسارك"),'setup','secondary','settings'))+
 `<div class="dash"><div class="stack"><section class="card"><div class="spread"><h2>${msg("المحطات العشر")}</h2>${badge(msg("دورة ")+msg(cycle()?.title),'gold')}</div>${stations.map(([title,summary,dest,time],i)=>row(title,msg(summary)+' · '+msg(time),stationTarget(dest),String(i+1).padStart(2,'0'),stationDone(i))).join('')}</section></div>
 <div class="stack"><section class="card"><h2>${msg("خطة المراجعة")}</h2><p>${p?localized(track()?.title)+' · '+fmt(p.minutes)+msg(" دقيقة يوميا · ")+fmt(p.days)+msg(" يوما"):msg("اختر السلك والتخصص لتخصيص الوقت والمهام.")}</p>${progress(st.coverage)}<p class="small">${fmt(st.done.length)} ${msg("درس مكتمل من")} ${fmt(available().length)} ${msg("درس متاح")}</p>
 ${!p?link(msg("اضبط خطة الاستعداد"),'setup','slim'):plan.map(slot=>`<details class="lesson-section" ${slot.id===0?'open':''}><summary>${dateLabel(slot.date)} · ${fmt(slot.minutes)} ${msg("دقيقة")}</summary>${slot.overflow?`<p class="small">${msg("تتجاوز هذه الحصة الوقت اليومي المحدد.")}</p>`:''}${slot.items.map(id=>row(byLesson[id].title,data.domains[byLesson[id].domain],'lesson/'+id,icon('book',15))).join('')}</details>`).join('')}
 ${p&&!plan.length?`<p>${msg("اكتملت الدروس المتاحة. تابع الاختبارات والمراجعة.")}</p>`:''}${p?`<div class="notice small">${({ 'الكتب والمراجع':msg("ابدأ بقراءة مراجع الدرس المرتبطة به."),الملخصات:msg("راجع خلاصة الدرس وبطاقاته قبل التطبيق."),الاختبارات:msg("ابدأ بسؤال الدرس ثم ارجع إلى شرح أخطائك.")})[p.preference]??msg("اقرأ الشرح ثم اختبر نفسك وثبّت أخطاءك.")}</div>`:''}</section>
 <section class="card"><h2>${msg("قراءات أضفتها")}</h2>${state.queued.length?state.queued.filter(id=>bySource[id]).map(id=>`<p>${action(esc(bySource[id].title),'source/'+id,'secondary slim')}</p>`).join(''):`<p>${msg("أضف المراجع من المكتبة لتظهر هنا.")}</p>`}</section></div></div>`;
}
function lessonsPage(domain){
 const ls=available().filter(l=>l.domain===domain), t=track();
 return head(localized(data.domains[domain]),domain==='subject'?(t?localized(data.levels[t.level])+' · '+localized(t.title):msg("اختر تخصصك لعرض الدروس المرتبطة به.")):msg("دروس وملخصات وبطاقات استرجاع وأسئلة تطبيقية."),domain==='subject'?link(msg("اختيار التخصص"),'setup','secondary','settings'):'')+
 (domain==='subject'&&t?`<div class="notice">${localized(t.status)}. ${msg("التوصيف التفصيلي للدورة بانتظار التحقق.")} ${outside(msg("بنية الاختبارات الرسمية"),bySource[t.source]?.url)}</div>`:'')+
 (ls.length?`<div class="grid">${ls.map(l=>`<article class="card book-card">${tile(domain==='didactics'?'stack':'book',domain==='didactics'?'green':'')}<div class="tags">${badge(fmt(l.minutes)+msg(" دقيقة"),'neutral')}${state.completed[l.id]?badge(msg("مكتمل"),'ok'):''}</div><h3 dir="auto">${esc(l.title)}</h3><p dir="auto">${esc(l.objective)}</p><div class="actions">${link(msg("افتح الدرس"),'lesson/'+l.id,'slim','arrow')}</div></article>`).join('')}</div>`:empty(msg("لم تدرج دروس خاصة بهذا الاختيار بعد"),msg("يمكنك متابعة علوم التربية والديداكتيك المشترك والرجوع إلى إعلان الدورة."),'book',link(msg("علوم التربية"),'education','secondary slim')));
}
function lessonPage(id){
 const l=byLesson[id];if(!l)return empty(msg("الدرس غير متاح"),msg("اختر درسا من المسار."));
 const lessonSections=[[msg("أهداف التعلم"),l.objective],[msg("المتطلبات السابقة"),l.prerequisite],[msg("الشرح المبسط"),l.explanation],[msg("الشرح الموسع"),l.academic],[msg("مثال من الممارسة الصفية"),l.example],[msg("مفاهيم أساسية"),l.terms?.join(' · ')],[msg("مقارنة المفاهيم"),l.compare],[msg("خطأ شائع"),l.mistake],[msg("خلاصة مركزة"),l.summary]];
 return head(`<span dir="auto">${esc(l.title)}</span>`,localized(data.domains[l.domain])+' · '+fmt(l.minutes)+msg(" دقيقة"),link(msg("العودة إلى الدروس"),l.domain,'secondary slim'))+
 `<article class="card study">${badge(l.status,'neutral')}<div class="section">${lessonSections.map(([label,content])=>`<section class="lesson-section"><h3>${label}</h3><p dir="auto">${esc(content)}</p></section>`).join('')}<section class="lesson-section"><h3>${msg("بطاقات استرجاع")}</h3><details><summary>${msg("ما الفكرة التي أسترجعها؟")}</summary><p dir="auto">${esc(l.summary)}</p></details><details><summary>${msg("ما الخطأ الذي أتجنبه؟")}</summary><p dir="auto">${esc(l.mistake)}</p></details></section><section class="lesson-section"><h3>${msg("المراجع والقراءة")}</h3><div class="actions">${l.refs.filter(ref=>bySource[ref]).map(ref=>action(esc(bySource[ref].title),'source/'+ref,'secondary slim')).join('')}</div></section><section class="lesson-section"><h3>${msg("دروس مرتبطة")}</h3><div class="actions">${available().filter(x=>x.domain===l.domain&&x.id!==l.id).slice(0,2).map(x=>link(esc(x.title),'lesson/'+x.id,'secondary slim')).join('')}</div></section></div><div class="actions">${action(state.completed[id]?msg("إلغاء إتمام الدرس"):msg("علّم الدرس كمكتمل"),'complete/'+id,'secondary','check')}${data.questions.some(q=>q.lesson===id)?link(msg("اختبر فهمك"),'lab/lesson-'+id,'','test'):''}</div></article>`;
}


function library(){
 const kinds=[...new Set(data.sources.map(x=>x.kind))];
 return head(msg("المكتبة الرقمية"),msg("مراجع مرتبة حسب الصلة بالمسار، مع روابط أصلية وبيانات تحقق."))+
 `<form id="filters" class="filters"><label class="field">${msg("ابحث في العنوان أو المحور")}<input name="query" type="search" dir="auto" placeholder="${msg("مثلا التقويم أو خارطة الطريق")}"></label>
 ${select('level',msg("السلك"),[['',msg("كل الأسلاك")],...Object.entries(data.levels)])}
 <div id="librarySubject">${librarySubjects('')}</div>
 ${select('domain',msg("المجال"),[['',msg("كل المجالات")],...Object.entries(data.domains),['match',msg("المباراة")]])}
 ${select('kind',msg("نوع الوثيقة"),[['',msg("كل الوثائق")],...kinds.map(x=>[x,x])])}
 ${select('priority',msg("الأولوية"),[['',msg("كل الأولويات")],...['أساسي','مهم','للتوسع'].map(x=>[x,x])])}
 ${select('saved',msg("العرض"),[['',msg("جميع المراجع")],['1',msg("مكتبتي")]])}</form><div id="book-results"></div>`;
}
function librarySubjects(level,selected=''){
 const options=new Map(data.tracks.filter(t=>!level||t.level===level).map(t=>[t.subject,t.title]));
 return select('subject',msg("التخصص"),[['',msg("كل التخصصات")],...options],selected);
}
let libraryFilters={};
function filterLibrary(){
 const form=document.querySelector('#filters');if(!form)return;
 const f=Object.fromEntries(new FormData(form));libraryFilters=f;
 const tokens=normalize(f.query).split(' ').filter(Boolean);
 const items=data.sources.filter(x=>{
  const labels=[x.title,x.publisher,x.author,x.summary,x.kind,x.domain,data.domains[x.domain]];
  const hay=normalize([...labels,...labels.map(msg)].join(' '));
  return tokens.every(word=>hay.includes(word))&&(!f.level||x.level==='all'||x.level===f.level)&&(!f.subject||x.subject==='all'||x.subject===f.subject)&&
  (!f.domain||x.domain===f.domain)&&(!f.kind||x.kind===f.kind)&&(!f.priority||x.priority===f.priority)&&(!f.saved||state.saved.includes(x.id));
 });
 document.querySelector('#book-results').innerHTML=items.length?`<p class="small muted" aria-live="polite">${fmt(items.length)} ${msg("مرجع")}</p><div class="grid">${items.map(bookCard).join('')}</div>`:empty(msg("لا نتائج بهذه المرشحات"),msg("غيّر كلمات البحث أو وسّع نطاق المرشحات."),'search');
}
function sourceDetails(id){
 const x=bySource[id];if(!x)return;
 openModal(x.title,`<dl><dt>${msg("الجهة الناشرة")}</dt><dd>${localized(x.publisher)}${x.author?' · '+esc(x.author):''}</dd><dt>${msg("المجال والسلك والتخصص")}</dt><dd>${localized(data.domains[x.domain]??'المباراة')} · ${localized(data.levels[x.level]??'كل الأسلاك')} · ${localized(x.subject==='all'?'مشترك':data.tracks.find(item=>item.subject===x.subject)?.title??x.subject)}</dd><dt>${msg("السنة واللغة والصعوبة")}</dt><dd>${x.year?esc(x.year):msg("دون تاريخ نشر محدد")} · ${localized(x.lang)} · ${localized(x.difficulty)}</dd><dt>${msg("تاريخ آخر تحقق")}</dt><dd dir="ltr">${esc(x.checked)}</dd><dt>${msg("الحقوق")}</dt><dd>${localized(x.license)}</dd><dt>${msg("حالة الوثيقة والرابط")}</dt><dd>${localized(x.status)} · ${localized(x.linkStatus)}</dd></dl><div class="actions">${outside(msg("افتح المصدر الأصلي"),x.url)}${x.pdf?action(msg("اقرأ الآن"),'pdf/'+id,'','book'):''}</div>`);
}
function notices(){
 const c=cycle(), items=data.sources.filter(s=>s.kind==='إعلان رسمي'||s.kind==='بلاغ رسمي');
 return head(msg("الإعلانات الرسمية"),msg("وثائق الجهة المنظمة، مرتبة ومؤرخة بحسب الدورة."))+
 `<section class="card"><div class="card-head"><div><h2>${msg("محطات دورة")} ${localized(c.title)}</h2><small>${msg("التوقيت المحلي للمغرب")}</small></div>${tile('calendar','gold')}</div><div class="grid"><div class="notice"><strong>${msg("آخر أجل للترشيح")}</strong><br>${dateLabel(c.deadline.slice(0,10))} ${esc(c.deadline.slice(0,4))} · ${esc(c.deadline.slice(11,16))}</div><div class="notice"><strong>${msg("الاختبارات الكتابية")}</strong><br>${dateLabel(c.writtenDate)} ${esc(c.writtenDate.slice(0,4))}</div><div class="notice"><strong>${msg("الفترة المعلنة للشفوي")}</strong><br>${c.oralFrom&&c.oralTo?dateLabel(c.oralFrom)+' – '+dateLabel(c.oralTo)+' '+esc(c.oralTo.slice(0,4)):msg("راجع إعلان الدورة")}</div></div><div class="actions">${action(state.finished.rules?msg("إلغاء علامة الاطلاع"):msg("اطلعت على الإعلان"),'rules','secondary slim','check')}</div></section><div class="grid section">${items.map(bookCard).join('')}</div><div class="notice">${msg("بطاقات التوصيف التفصيلية بانتظار التحقق. المدد والمعاملات المتاحة مأخوذة من ص 4–5 من الإعلان الأصلي.")}</div>`;
}
function archive(){
 const t=track(), items=data.archives.filter(x=>!t||(!x.track||x.track===t.id)&&(!x.levels||x.levels.includes(t.level)));
 const records=items.map(x=>`<article class="card book-card">${tile('file')}<div class="tags">${badge(x.kind,'neutral')}${badge(x.cycleLabel??x.cycle,'gold')}</div><h3 dir="auto">${esc(x.title)}</h3><p>${localized(x.status??"راجع بيانات الجهة الناشرة.")}</p><p class="small">${esc(x.publisher??msg("مصدر خارجي"))}${x.minutes?' · '+fmt(x.minutes)+msg(" دقيقة"):''}${x.weight?msg(" · المعامل ")+fmt(x.weight):''}</p><div class="actions">${outside(msg("صفحة الناشر"),x.url)}${x.pdf?outside(msg("PDF لدى الناشر"),x.pdf,'secondary slim','download'):''}${x.correction?outside(x.officialCorrection?msg("التصحيح الرسمي"):msg("تصحيح مقترح غير رسمي"),x.correction):''}</div></article>`).join('');
 return head(msg("الامتحانات السابقة"),msg("فهرس المواضيع الأصلية بعد التحقق من الدورة والمصدر وحقوق الإتاحة."))+
 (items.length?`<div class="notice">${msg("المواضيع التالية من دورات سابقة. تعرض كل بطاقة حالة مطابقة الأصل والجهة التي أعدت التصحيح.")}</div><div class="grid">${records}</div>`:empty(msg("الأرشيف لهذا المسار قيد الإعداد"),msg("لم يدرج موضوع سابق لهذا الاختيار. يمكنك حل تدريب مؤلف مع تصحيح معلل."),'file',link(msg("مختبر الاختبارات"),'lab','secondary','test')));
}
const labItems={
 diagnostic:['الاختبار التشخيصي','عينة من المجالات المتاحة لترتيب خطة المراجعة.',0,'target'],
 education:['اختبار علوم التربية','التقويم ونظريات التعلم والتدريس الفارقي.',0,'book'],
 subject:['اختبار التخصص','أسئلة خاصة بالمحتوى المتاح لمسارك.',0,'pen'],
 didactics:['اختبار الديداكتيك','التخطيط والمعالجة والتدبير.',0,'stack'],
 practice:['تحليل الوضعيات المهنية','أسئلة تطبيقية في التقويم والتدبير.',0,'file'],
 simulation:['محاكاة تدريبية مصغرة','تدريب مؤلف وموقّت في المجالات المتاحة.',12,'clock'],
 mistakes:['إعادة مراجعة الأخطاء','أعد حل الأسئلة التي بقيت في دفتر الأخطاء.',0,'again']
};
function questionSet(kind){
 const map=Object.fromEntries(available().map(l=>[l.id,l]));
 const all=data.questions.filter(q=>map[q.lesson]);
 if(kind.startsWith('lesson-'))return data.questions.filter(q=>q.lesson===kind.slice(7));
 if(kind==='mistakes')return all.filter(q=>state.review[q.id]);
 if(kind==='diagnostic')return all.filter((q,i)=>all.findIndex(a=>a.lesson===q.lesson)===i);
 if(kind==='practice')return all.filter(q=>['a3','p1','e1','e2','c1','c2','i1'].includes(q.id));
 if(kind==='simulation')return all.filter(q=>!['a1','l1','p1','i1','e1','c1','f1','ar1','fr1','s1','is1'].includes(q.id)).slice(0,16);
 return all.filter(q=>map[q.lesson].domain===kind);
}
const activeQuestion=(attempt,id)=>attempt.questions?.[id]??byQuestion[id];
const quizTitle=kind=>labItems[kind]?.[0]??'اختبار الدرس';
function lab(kind){
 if(!kind){
  return head(msg("مختبر الاختبارات"),msg("اختر تشخيصا أو تدريبا بحسب المجال ثم راجع التصحيح المفصل."),state.active?link(msg("استأنف الاختبار"),'lab/'+state.active.kind,'','test'):'')+
  `<div class="grid">${Object.entries(labItems).map(([id,[title,description,minutes,ic]])=>`<article class="card book-card">${tile(ic)}<h3>${localized(title)}</h3><p>${localized(description)}</p><p class="small">${fmt(questionSet(id).length)} ${msg("سؤال")}${minutes?' · '+fmt(minutes)+msg(" دقيقة"):''}</p>${link(msg("تفاصيل الاختبار"),'lab/'+id,'secondary slim','arrow')}</article>`).join('')}</div>`;
 }
 const a=state.active;
 if(a?.kind===kind)return quiz(a);
 const list=questionSet(kind), config=labItems[kind];
 return head(localized(quizTitle(kind)),localized(config?.[1]??"اختبار قصير من محتوى الدرس."),link(msg("العودة إلى المختبر"),'lab','secondary slim'))+
 (kind==='simulation'?officialTable():'')+
 `<section class="card study"><div class="tags">${badge(msg("تدريب من إعداد الأكاديمية"),'gold')}${badge(fmt(list.length)+msg(" سؤال"),'neutral')}</div><p class="section">${msg("الأسئلة مرجعية للتدريب وبانتظار مراجعة علمية مستقلة. تظهر الإجابات المعللة بعد التسليم.")}</p>
 ${kind==='diagnostic'&&!track()?`<div class="notice">${msg("لتخصيص التشخيص، اختر مسارا أولا. يمكنك اجتياز التشخيص المشترك الآن.")} ${link(msg("اختر مسارك"),'setup','secondary slim')}</div>`:''}
 ${kind==='simulation'?`<div class="notice">${msg("مدة هذه المحاولة 12 دقيقة وبنقطة تدريبية موحدة. تعرض الجداول المجاورة قواعد الدورة الرسمية. بناء نموذج كامل لكل مكون قيد الإعداد.")}</div>`:''}
 ${a?`<div class="notice">${msg("توجد محاولة محفوظة.")} ${link(msg("استأنف المحاولة"),'lab/'+a.kind,'secondary slim')} ${action(msg("اترك المحاولة الحالية"),'discard','secondary slim')}</div>`:''}
 ${list.length?action(msg("ابدأ الاختبار"),'start/'+kind,'','test'):`<p>${msg("لا توجد أسئلة متاحة لهذا الاختيار حاليا.")}</p>`}</section>`;
}
function officialTable(){
 const c=cycle(), t=track(), e=exams();
 if(!t)return `<div class="card notice">${msg("اختر تخصصك لعرض جدول المدد والمعاملات.")} ${link(msg("اختيار التخصص"),'setup','secondary slim')}</div>`;
 return `<section class="card study" style="margin-bottom:14px"><div class="card-head"><h2>${msg("بنية الكتابي")} · ${localized(c.title)}</h2>${outside(msg("الإعلان الأصلي"),bySource[c.source]?.pdf??bySource[c.source]?.url)}</div><div class="table-wrap"><table><thead><tr><th>${msg("المجال")}</th><th>${msg("المكون")}</th><th>${msg("الدقائق")}</th><th>${msg("المعامل")}</th></tr></thead><tbody>${e.map(x=>`<tr><td>${localized(data.domains[x.domain])}</td><td>${localized(x.title)}</td><td>${fmt(x.minutes)}</td><td>${fmt(x.weight)}</td></tr>`).join('')}</tbody></table></div><p class="small">${msg("الإقصاء الكتابي في الإعلان عند نقطة أقل من")} ${fmt(c.writtenThreshold)}${msg("/20 في أحد المكونات.")}${t.subject==='pe'?msg(" الاختبار العملي بعد الكتابي، ونقطة أقل من ")+fmt(c.physicalThreshold)+msg("/20 إقصائية فيه."):''}</p></section>`;
}
function quiz(a){
 const q=activeQuestion(a,a.ids[a.position]);
 if(!q)return empty(msg("تعذر فتح السؤال"),msg("اترك المحاولة الحالية ثم ابدأ محاولة جديدة."),'test',action(msg("اترك المحاولة"),'discard'));
 const saved=a.answers[q.id];
 const choices=q.type==='short'?`<label class="field">${msg("إجابتك")}<input id="shortAnswer" type="text" dir="auto" maxlength="150" value="${esc(saved??'')}"></label>`:
 q.type==='order'?`<div class="stack"><p>${msg("انقر العناصر بالترتيب المطلوب.")}</p>${q.options.map((option,i)=>`<button class="btn secondary" type="button" data-action="order/${i}" ${saved?.includes(i)?'disabled':''}>${saved?.includes(i)?fmt(saved.indexOf(i)+1)+'. ':''}${esc(option)}</button>`).join('')}${action(msg("امسح الترتيب"),'order-reset','secondary slim')}</div>`:
 q.options.map((option,i)=>`<label class="option"><input type="${q.type==='multi'?'checkbox':'radio'}" name="answer" value="${i}" ${q.type==='multi'?(saved?.includes(i)?'checked':''):(saved===i?'checked':'')}><span dir="auto">${esc(option)}</span></label>`).join('');
 return head(localized(quizTitle(a.kind)),msg("إجاباتك تُحفظ خلال التنقل بين الأسئلة."),a.ends?`<div class="badge gold">${icon('clock',17)}<span dir="ltr" id="quiz-clock" aria-label="${msg("الوقت المتبقي")}"></span></div>`:'')+
 `<section class="card study"><div class="spread"><span class="badge">${msg("السؤال")} ${fmt(a.position+1)} ${msg("من")} ${fmt(a.ids.length)}</span><span class="small muted">${fmt(Object.keys(a.answers).length)} ${msg("إجابة محفوظة")}</span></div>
 <div class="test-nav" aria-label="${msg("انتقل إلى سؤال")}">${a.ids.map((id,i)=>`<button class="btn secondary slim" data-action="question/${i}" aria-label="${msg("السؤال")} ${i+1}" aria-current="${a.position===i}">${id in a.answers?icon('check',13):''}${fmt(i+1)}</button>`).join('')}</div>
 <div class="lesson-section"><h2 dir="auto">${esc(q.prompt)}</h2><div class="section">${choices}</div></div><div class="actions">
 ${a.position>0?action(msg("السابق"),'question/'+(a.position-1),'secondary'):''}
 ${a.position<a.ids.length-1?action(msg("السؤال التالي"),'question/'+(a.position+1),'','arrow'):''}
 ${action(msg("سلّم الاختبار"),'finish-confirm','secondary','check')}</div></section>`;
}
function startQuiz(kind){
 if(state.active){toast(msg("استأنف المحاولة الحالية أو اتركها قبل بدء اختبار جديد."));return;}
 const qs=questionSet(kind);if(!qs.length)return;
 const start=Date.now(), minutes=labItems[kind]?.[2]??0;
 state.active={id:crypto.randomUUID?.()??[...crypto.getRandomValues(new Uint8Array(16))].map(b=>b.toString(16).padStart(2,'0')).join(''),kind,title:quizTitle(kind),track:track()?.id??null,ids:qs.map(q=>q.id),questions:index(qs),answers:{},position:0,start,ends:minutes?start+minutes*60000:null};
 save();render();
}
function finishQuiz(){
 const a=state.active;if(!a)return;
 const qs=a.ids.map(id=>activeQuestion(a,id)).filter(Boolean), today=dayKey();
 const result={...score(qs,a.answers,byLesson),id:a.id,title:a.title,kind:a.kind,track:a.track,date:today,seconds:Math.max(0,Math.round((Math.min(a.ends??Infinity,Date.now())-a.start)/1000))};
 for(const item of result.items){
  const q=activeQuestion(a,item.id);
  item.feedback={prompt:q.prompt,answer:answerText(q,item.answer),solution:answerText(q,q.answer),why:q.why};
  if(!item.right){state.review[item.id]={step:0,due:reviewDate(1),last:today};}
  else if(state.review[item.id])advanceReview(item.id,true,false);
 }
 state.attempts=[result,...state.attempts].slice(0,150);
 while(state.attempts.length>1&&JSON.stringify(state.attempts).length>320000)state.attempts.pop();state.active=null;save();closeModal();go('result/'+a.id);
}
function answerText(q,value){
 if(value===null||value===undefined)return 'دون إجابة';
 if(q.type==='short')return Array.isArray(value)?value[0]:value;
 if(Array.isArray(value))return value.map(i=>q.options[i]).join(' ← ')||'دون إجابة';
 return q.options[value]??'دون إجابة';
}
function resultPage(id){
 const r=state.attempts.find(x=>x.id===id);if(!r)return empty(msg("النتيجة غير موجودة"),msg("النتائج تظهر بعد تسليم الاختبار."));
 return head(localized(quizTitle(r.kind)),msg("تصحيح تدريبي · ")+dateLabel(r.date),link(msg("خطة المراجعة"),'path','secondary','path'))+
 `<div class="metrics">${[[msg("النقطة على 20"),r.total?fmt(20*r.right/r.total):'—','target'],[msg("النسبة"),r.percent+'%','chart'],[msg("الصحيحة / الأخرى"),r.right+' / '+(r.total-r.right),'check'],[msg("الوقت"),clockText(r.seconds),'clock']].map(([label,value,ic])=>`<div class="metric">${tile(ic)}<div><strong>${esc(value)}</strong><small>${label}</small></div></div>`).join('')}</div>
 <section class="card"><h2>${msg("تحليل المجالات")}</h2>${Object.entries(r.by).map(([id,b])=>`<p>${localized(data.domains[id]??id)} · ${fmt(b.correct)}/${fmt(b.total)}</p>${progress(Math.round(b.correct*100/b.total))}`).join('')}</section>
 <div class="stack section">${r.items.map(item=>{
  const q=byQuestion[item.id], l=byLesson[item.lesson], feedback=item.feedback;if(!q&&!feedback)return '';
  return `<article class="card result ${item.right?'good':''}">${badge(item.right?msg("صحيحة"):item.answer===null?msg("متروكة"):msg("تحتاج إلى مراجعة"),item.right?'ok':'warn')}<h3 dir="auto">${esc(feedback?.prompt??q.prompt)}</h3><p dir="auto">${msg("إجابتك")}: ${item.answer===null?msg("دون إجابة"):esc(feedback?.answer??answerText(q,item.answer))}</p><p dir="auto">${msg("التصحيح")}: ${esc(feedback?.solution??answerText(q,q.answer))} · ${esc(feedback?.why??q.why)}</p><div class="actions">${l?link(msg("راجع الدرس"),'lesson/'+l.id,'secondary slim'):''}${l?.refs?.[0]&&bySource[l.refs[0]]?action(msg("مرجع الشرح"),'source/'+l.refs[0],'secondary slim'):''}</div></article>`;
 }).join('')}</div>`;
}
function clockText(seconds){const s=Math.max(0,Math.ceil(seconds));return String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0');}
function advanceReview(id,remembered,notify=true){
 const current=state.review[id];if(!current)return;
 const next=remembered?Math.min(current.step+1,4):0;
 state.review[id]={step:next,due:reviewDate([1,3,7,14,30][next]),last:dayKey()};
 if(notify){save();render();toast(msg("حُدّث موعد المراجعة."));}
}
function errors(){
 const list=questionSet('mistakes').sort((a,b)=>state.review[a.id].due.localeCompare(state.review[b.id].due)), due=list.filter(q=>state.review[q.id].due<=dayKey());
 return head(msg("دفتر أخطائي"),msg("استرجع الفكرة قبل كشف التصحيح. تتباعد المراجعات مع كل استرجاع ناجح."),list.length?link(msg("أعد اختبار الأخطاء"),'lab/mistakes','','again'):'')+
 (list.length?`<p class="notice">${fmt(due.length)} ${msg("بطاقة مستحقة الآن من")} ${fmt(list.length)} ${msg("بطاقة.")}</p><div class="stack">${list.map(q=>`<article class="card"><div class="tags">${badge(state.review[q.id].due<=dayKey()?msg("مستحقة"):msg("الموعد ")+dateLabel(state.review[q.id].due),'neutral')}</div><h3 dir="auto">${esc(q.prompt)}</h3><details><summary>${msg("اكشف الشرح")}</summary><p dir="auto">${esc(answerText(q,q.answer))} · ${esc(q.why)}</p><div class="actions">${action(msg("تذكرتها"),'review-good/'+q.id,'secondary slim')}${action(msg("أحتاج إلى تكرار"),'review-bad/'+q.id,'secondary slim')}${link(msg("راجع الدرس"),'lesson/'+q.lesson,'secondary slim')}</div></details></article>`).join('')}</div>`:empty(msg("لم تسجل أخطاء بعد"),msg("يظهر هنا ما يحتاج إلى مراجعة بعد تسليم الاختبار."),'again',link(msg("ابدأ اختبارا"),'lab','secondary slim')))+
 `<div class="section">${action(state.finished.final?msg("إلغاء إتمام المراجعة النهائية"):msg("علّم المراجعة النهائية كمكتملة"),'final','secondary slim','check')}</div>`;
}


let recording=null,audioURL='',recordedBlob=null,oralDeadline=0,oralPhase='',oralRecordRequest=0;
function oralPage(){
 const c=cycle(), scenario=data.oral.find(x=>x.id===arg)??data.oral[0];
 if(!scenario)return empty(msg("تمارين الشفوي قيد الإعداد"),msg("تابع الإعلان الرسمي لمعرفة البنية."));
 const saved=state.oral[scenario.id]??{};
 return head(msg("أستعد للشفوي"),msg("حضّر مقطعا تعليميا أو وضعية مهنية، ثم راجع جوابك بشبكة إرشادية."))+
 `<div class="dash"><div class="card form"><label class="field">${msg("الوضعية التدريبية")}<select id="oralSelect">${data.oral.map(x=>`<option value="${x.id}" ${x.id===scenario.id?'selected':''}>${esc(x.title)}</option>`).join('')}</select></label><h2 dir="auto">${esc(scenario.title)}</h2><p dir="auto">${esc(scenario.prompt)}</p>
 <div class="actions">${action(msg("تحضير · 3 دقائق"),'oral-clock/prep','secondary slim','clock')}${action(msg("إجابة · 4 دقائق"),'oral-clock/answer','secondary slim','mic')}<strong id="oral-clock" dir="ltr"></strong></div>
 <label class="field">${msg("إجابتك المكتوبة")}<textarea id="oralAnswer" dir="auto" data-id="${scenario.id}" rows="5" maxlength="5000" placeholder="${msg("صغ جوابك أو سجّل صوتك أدناه")}">${esc(saved.text)}</textarea></label>
 <div class="actions">${action(recording?msg("أوقف التسجيل"):msg("ابدأ التسجيل الصوتي"),recording?'record-stop':'record-start','secondary slim','mic')}${audioURL?`<a class="btn secondary slim" href="${esc(audioURL)}" download="oral-practice.${recordedBlob?.type.includes('mp4')?'m4a':'webm'}">${msg("نزّل تسجيلي")}</a>${action(msg("احذف التسجيل"),'record-delete','secondary slim') }`:''}</div>
 ${audioURL?`<audio controls src="${esc(audioURL)}"></audio>`:''}<small class="muted">${msg("يطلب المتصفح إذن الميكروفون. التسجيل الصوتي يبقى في هذه الجلسة ويمكنك تنزيله.")}</small>
 <fieldset><legend>${msg("التقييم الذاتي الإرشادي")}</legend>${scenario.rubric.map((value,i)=>`<label class="option"><input class="rubric" type="checkbox" value="${i}" data-id="${scenario.id}" ${saved.checks?.includes(i)?'checked':''}><span dir="auto">${esc(value)}</span></label>`).join('')}</fieldset>
 <div class="actions">${action(saved.complete?msg("إلغاء إتمام التدريب"):msg("احفظ التدريب كمكتمل"),'oral-complete/'+scenario.id,'','check')}</div></div>
 <aside class="card"><div class="card-head"><h2>${msg("البنية الرسمية")}</h2>${badge(c.title,'gold')}</div><p>${msg("التحضير")} ${fmt(c.oral.preparation)} ${msg("دقيقة · العرض")} ${fmt(c.oral.presentation)} ${msg("دقيقة · المناقشة")} ${fmt(c.oral.discussion)} ${msg("دقيقة · المعامل")} ${fmt(c.oral.weight)}.</p><p>${msg("التمرين المصغر للتدرب على تقديم الأفكار ومناقشتها.")}</p>${outside(msg("الإعلان الرسمي"),bySource[c.source]?.pdf??bySource[c.source]?.url)}</aside></div>`;
}
function stopRecording(){
 oralRecordRequest++;
 if(recording&&recording.state!=='inactive')recording.stop();
}
async function startRecording(){
 if(!navigator.mediaDevices?.getUserMedia||!window.MediaRecorder){toast(msg("التسجيل غير مدعوم في هذا المتصفح أو الاتصال."));return;}
 const request=++oralRecordRequest;
 let stream;
 try{
  stream=await navigator.mediaDevices.getUserMedia({audio:true});
  if(request!==oralRecordRequest||route!=='oral'){stream.getTracks().forEach(t=>t.stop());return;}
  const chunks=[],r=new MediaRecorder(stream);recording=r;
  r.ondataavailable=e=>{if(e.data.size)chunks.push(e.data);};
  r.onstop=()=>{
   stream.getTracks().forEach(t=>t.stop());
   if(recording===r)recording=null;
   if(audioURL)URL.revokeObjectURL(audioURL);
   recordedBlob=new Blob(chunks,{type:r.mimeType});audioURL=chunks.length?URL.createObjectURL(recordedBlob):'';
   if(route==='oral')render();
  };
  r.start();render();
 }catch{stream?.getTracks().forEach(t=>t.stop());recording=null;toast(msg("تعذر بدء التسجيل. راجع إذن الميكروفون."));}
}
function guide(){
 return head(msg("مرشدي نحو النجاح"),msg("ابحث في شروح الأكاديمية وخلاصاتها مع المراجع المرتبطة بها."))+
 `<section class="card study form"><form id="guide" class="form"><label class="field">${msg("ما المفهوم الذي تريد فهمه؟")}<input name="query" type="search" dir="auto" placeholder="${msg("مثلا التقويم التكويني أو تحليل الخطأ")}" required maxlength="180"></label><div class="actions">${submit(msg("ابحث في الشروح"))}</div></form><p class="small muted">${msg("يعرض المرشد مقاطع مطابقة من المحتوى الحالي ومصادرها. الإجابات التوليدية غير متاحة في هذه النسخة.")}</p><div id="guide-results" aria-live="polite"></div></section>`;
}
function guideResults(query){
 const terms=normalize(query).split(' ').filter(w=>w.length>2&&!['كيف','شرح','معنى','تعريف','اريد','اريد','الفرق','ماذا','الذي'].includes(w));
 const ranked=available().map(l=>{
  const title=normalize(l.title), body=normalize([l.explanation,l.terms.join(' '),l.summary,l.academic].join(' '));
  return {l,score:terms.reduce((n,w)=>n+(title.includes(w)?3:body.includes(w)?1:0),0)};
 }).filter(x=>x.score>0).sort((a,b)=>b.score-a.score).slice(0,3);
 document.querySelector('#guide-results').innerHTML=ranked.length?ranked.map(({l})=>`<article class="lesson-section"><h3>${esc(l.title)}</h3><p dir="auto">${esc(l.explanation)}</p><div class="actions">${link(msg("الدرس الكامل"),'lesson/'+l.id,'secondary slim')}${l.refs.filter(id=>bySource[id]).map(id=>action(esc(bySource[id].title),'source/'+id,'secondary slim')).join('')}</div></article>`).join(''):`<p class="notice">${msg("لم أجد مقطعا يكفي للإجابة في المحتوى الحالي. جرب مصطلحا مثل السقالة أو التغذية الراجعة.")}</p>`;
}
function statsPage(){
 const s=stats(), by={};
 for(const a of s.attempts)for(const [id,v] of Object.entries(a.by)){by[id]??={total:0,correct:0};by[id].total+=v.total;by[id].correct+=v.correct;}
 const ranks=Object.entries(by).sort(([,a],[,b])=>b.correct/b.total-a.correct/a.total);
 const timeline=s.attempts.slice(0,8).reverse();
 return head(msg("إحصائياتي"),msg("تعرف على أدائك حسب المجال وحدد أولويات المراجعة."),link(msg("دفتر أخطائي"),'errors','secondary','again'))+
 `<div class="metrics">${[[msg("مؤشر الجاهزية"),s.index+'%','target'],[msg("متوسط الاختبارات"),s.avg+'%','chart'],[msg("دقائق الدراسة التقديرية"),s.minutes,'clock'],[msg("أيام النشاط من 7"),s.days,'calendar']].map(([label,value,ic])=>`<div class="metric">${tile(ic)}<div><strong>${value}</strong><small>${label}</small></div></div>`).join('')}</div><div class="dash"><section class="card"><h2>${msg("تطور النتائج")}</h2>${timeline.length?`<div class="chart" aria-label="${msg("آخر النتائج")}">${timeline.map(a=>`<div><strong>${a.percent}%</strong><i style="height:${Math.max(2,a.percent*.85)}px"></i><span>${dateLabel(a.date)}</span></div>`).join('')}</div>${s.attempts.slice(0,10).map(a=>row(quizTitle(a.kind),dateLabel(a.date)+' · '+a.percent+'%','result/'+a.id,icon('test',15))).join('')}`:`<p>${msg("ابدأ باختبار للحصول على بيانات الأداء.")}</p>`}</section>
 <section class="card"><h2>${msg("الأداء حسب المجال")}</h2>${ranks.length?ranks.map(([id,a])=>`<p>${localized(data.domains[id]??id)} · ${a.correct}/${a.total}</p>${progress(Math.round(100*a.correct/a.total))}`).join(''):`<p>${msg("سيظهر التحليل بعد أول اختبار.")}</p>`}<div class="notice small">${msg("مؤشر تدريبي · 25% تغطية الدروس، 25% متوسط النتائج، 20% المحاكاة، 15% النشاط في 7 أيام، 15% نسبة الدروس التي أجبت فيها إجابة صحيحة. يستخدم المحتوى المتاح في هذا المسار.")}</div></section></div>`;
}
function settings(){
 return head(msg("الإعدادات"),msg("خصص الواجهة وراجع طريقة حفظ بياناتك."))+
 `<div class="grid"><section class="card form"><h2>${msg("المظهر")}</h2><div class="actions">${action(state.theme==='dark'?msg("الوضع الفاتح"):msg("الوضع الداكن"),'theme','secondary','moon')}</div><form id="appearance">${select('palette',msg("الألوان"),[['royal',msg("أزرق ملكي")],['emerald',msg("زمردي")],['violet',msg("بنفسجي")]],state.palette)}<label class="field">${msg('لغة الواجهة')}<select name="language" data-language>${languageOptions()}</select></label></form><p class="small muted">${msg('تُحفظ اللغة في هذا المتصفح. تظهر الدروس والأسئلة والوثائق بلغاتها الأصلية.')}</p></section>
 <section class="card form"><h2>${msg("حفظ التقدم")}</h2><p>${session?msg("حساب ")+esc(session.email):serverEnabled?msg("وضع الضيف يحفظ التقدم على هذا المتصفح."):msg("تحفظ نسخة GitHub Pages تقدمك في هذا المتصفح. الحسابات ولوحة الإدارة متاحتان في التشغيل المستقل.")}</p><div class="actions">${action(msg("صدّر بياناتي"),'export','secondary slim','download')}${session?action(msg("تسجيل الخروج"),'logout','secondary slim'):serverEnabled?link(msg("تسجيل أو إنشاء حساب"),'account','secondary slim'):''}${session?action(msg("حذف حسابي"),'delete-account','danger slim'):action(msg("مسح تقدمي المحلي"),'reset','danger slim')}</div></section>
 ${session&&session.role!=='learner'?`<section class="card"><h2>${msg("إدارة المحتوى")}</h2><p>${msg("المسودات والمراجعة والنشر وسجل التدقيق.")}</p>${link(msg("افتح لوحة الإدارة"),'admin','secondary slim','lock')}</section>`:''}<section class="card"><h2>${msg("حالة المحتوى")}</h2><p>${msg("تغطية تدريبية أولية. تتوفر المراجع الرسمية المحددة في الإعلانات؛ تبقى التوصيفات التفصيلية، الأرشيف الموثق والتغطية الكاملة للتخصصات قيد الاستكمال.")}</p></section></div>`;
}
function account(){
 if(!serverEnabled)return empty(msg("التشغيل في وضع الضيف"),msg("تعمل الحسابات عند تشغيل خادم المشروع المستقل."),'lock',link(msg("الإعدادات"),'settings','secondary slim'));
 if(session)return settings();
 return head(msg("حساب المترشح"),msg("استخدم حسابك لحفظ التقدم على خادم هذه النسخة."))+
 `<form id="account" class="card form study">${field('email',msg("البريد الإلكتروني"),'email','','required maxlength="254" autocomplete="username"')}${field('password',msg("كلمة المرور"),'password','','required minlength="12" maxlength="128" autocomplete="current-password"')}<div class="actions"><button class="btn" name="mode" value="login">${msg("دخول")}</button><button class="btn secondary" name="mode" value="register">${msg("إنشاء حساب")}</button></div><p class="small muted">${msg("إنشاء الحساب ينقل تقدم الضيف عند عدم وجود بيانات محفوظة في الحساب.")}</p><p id="account-message" role="status"></p></form>`;
}
const adminCollections={sources:'المراجع',lessons:'الدروس',questions:'الأسئلة',tracks:'المسارات',cycles:'الدورات',archives:'الأرشيف',oral:'الشفوي'};
let adminData, editRecord=null;
function admin(){
 if(!session||session.role==='learner')return empty(msg("لوحة الإدارة"),msg("يلزم حساب مخول للوصول."),'lock',link(msg("الإعدادات"),'settings','secondary slim'));
 if(!adminData){loadAdmin();return `<p role="status">${msg("جاري تحميل لوحة الإدارة…")}</p>`;}
 if(adminData.error)return empty(msg("تعذر تحميل البيانات"),localized(adminData.error),'lock',action(msg("أعد المحاولة"),'admin-refresh','secondary slim'));
 const {entries,audit,users,aggregate}=adminData, collection=editRecord?.collection??'sources';
 const mayPublish=['reviewer','admin'].includes(session.role);
 const rows=entries.map(r=>`<tr><td>${localized(adminCollections[r.collection])}</td><td dir="auto">${esc(r.record.title??r.record.prompt??r.record.id)}</td><td>${esc(({draft:msg("مسودة"),review:msg("بانتظار المراجعة"),published:msg("منشور"),superseded:msg("نسخة سابقة")})[r.status])}</td><td><div class="actions">${action(msg("افتح"),'admin-open/'+r.id,'secondary slim')}${r.status==='draft'?action(msg("إرسال للمراجعة"),'admin-submit/'+r.id,'secondary slim'):''}${r.status==='review'&&mayPublish?action(msg("اعتماد ونشر"),'admin-publish/'+r.id,'slim'):''}</div></td></tr>`).join('');
 return head(msg("إدارة الأكاديمية"),msg("تعديل مجموعات المحتوى، مراجعتها ونشرها مع سجل تدقيق."),action(msg("حدث القائمة"),'admin-refresh','secondary slim'))+
 `<div class="stack"><section class="card"><h2>${msg("المسودات والإصدارات")}</h2>${rows?`<div class="table-wrap"><table><thead><tr><th>${msg("المجموعة")}</th><th>${msg("العنصر")}</th><th>${msg("الحالة")}</th><th>${msg("الإجراء")}</th></tr></thead><tbody>${rows}</tbody></table></div>`:`<p>${msg("لا توجد مسودات. انسخ عنصرا من الكتالوج أو أنشئ سجلا جديدا.")}</p>`}</section>
 <section class="card form"><h2>${msg("محرر المحتوى")}</h2><label class="field">${msg("نسخ عنصر من الكتالوج")}<select id="admin-copy"><option value="">${msg("اختر سجلا للنسخ")}</option>${Object.entries(adminCollections).map(([key,label])=>`<optgroup label="${localized(label)}">${data[key].map(item=>`<option value="${key}/${item.id}">${esc(item.title??item.prompt)}</option>`).join('')}</optgroup>`).join('')}</select></label>
 <form id="admin-edit" class="form">${select('collection',msg("مجموعة المحتوى"),Object.entries(adminCollections),collection)}<label class="field">${msg("السجل بصيغة JSON")}<textarea name="record" rows="11" maxlength="65000" required dir="ltr">${esc(editRecord?JSON.stringify(editRecord.record,null,2):'{\n  "id": "",\n  "title": ""\n}')}</textarea></label><div class="actions">${submit(msg("احفظ كمسودة"))}</div></form><p class="small">${msg("تتحقق المنصة من بنية السجل والمراجع قبل الاعتماد. تحفظ المراجعات كإصدارات منفصلة.")}</p></section>
 ${users?`<section class="card"><h2>${msg("أدوار المستخدمين")}</h2><p>${aggregate.users} ${msg("حساب")} · ${aggregate.active} ${msg("حساب له تقدم محفوظ.")}</p><div class="stack section">${users.map(u=>`<form class="form-grid role-form" data-id="${u.id}"><span dir="auto">${esc(u.email)}</span><div class="actions">${select('role',msg("الدور"),[['learner',msg("مترشح")],['editor',msg("محرر")],['reviewer',msg("مراجع علمي")],['examiner',msg("مشرف اختبارات")],['admin',msg("مدير عام")]],u.role)}${submit(msg("احفظ"))}</div></form>`).join('')}</div></section>`:''}
 <section class="card"><div class="spread"><h2>${msg("سجل التدقيق")}</h2>${action(msg("صدّر السجل"),'audit-export','secondary slim','download')}</div>${audit.length?`<div class="table-wrap"><table><thead><tr><th>${msg("التوقيت")}</th><th>${msg("الإجراء")}</th><th>${msg("العنصر")}</th></tr></thead><tbody>${audit.map(x=>`<tr><td dir="ltr">${new Date(x.created_at).toISOString().slice(0,16).replace('T',' ')}</td><td>${esc(x.action)}</td><td>${esc(x.entity)}</td></tr>`).join('')}</tbody></table></div>`:`<p>${msg("لا عمليات مسجلة.")}</p>`}</section></div>`;
}
async function loadAdmin(){
 try{adminData=await api('/admin');}catch(error){adminData={error:error.message};}
 if(route==='admin')render();
}
async function refreshCatalog(){
 try {
  const {records}=await api('/content');
  data={...catalog};
  for(const [key,list] of Object.entries(records)){
   if(!adminCollections[key]||!Array.isArray(list))continue;
   const merged=new Map(data[key].map(item=>[item.id,item]));
   for(const item of list)merged.set(item.id,item);
   data[key]=[...merged.values()];
  }
  reindex();
 }catch{}
}
function openModal(title,body){
 if(pdfCleanup){pdfCleanup();pdfCleanup=null;}
 modal.innerHTML=`<div class="card-head"><h2 id="modal-title" dir="auto">${esc(title)}</h2><button class="icon-btn" data-action="close" aria-label="${msg("إغلاق")}">${icon('close')}</button></div>${body}`;
 if(!modal.open)modal.showModal();
}
function closeModal(){if(modal.open)modal.close();}
modal.addEventListener('close',()=>{if(!modal.open){pdfCleanup?.();pdfCleanup=null;}});
async function openPdf(id,file){
 const x=bySource[id], url=safeUrl(x?.pdf);
 if(!file&&!url)return;
 openModal(file?file.name:x.title,`<div class="actions pdf-controls"><button type="button" class="btn secondary slim" id="pdf-prev">${msg("السابق")}</button><label>${msg("صفحة")} <input type="number" id="pdf-page" min="1" value="1"></label><span id="pdf-count"></span><button type="button" class="btn secondary slim" id="pdf-next">${msg("التالي")}</button><button class="btn secondary slim" id="pdf-minus" aria-label="${msg("تصغير")}">−</button><button class="btn secondary slim" id="pdf-plus" aria-label="${msg("تكبير")}">+</button><button class="btn secondary slim" id="pdf-bookmark">${msg("علامة مرجعية")}</button><button class="btn secondary slim" id="pdf-full">${msg("ملء الشاشة")}</button></div><form id="pdf-search" class="actions section"><label>${msg("بحث في النص")} <input name="term" type="search" required maxlength="100"></label><button class="btn secondary slim">${msg("بحث")}</button></form><details id="pdf-outline" hidden><summary>${msg("فهرس الوثيقة")}</summary><div></div></details><details id="pdf-marks"><summary>${msg("العلامات المرجعية")}</summary><div></div></details><p id="pdf-status" role="status">${msg("جاري تحميل PDF…")}</p><div class="pdf-wrap" id="pdf-wrap"><canvas aria-label="${msg("صفحة PDF")}"></canvas></div><div class="actions">${outside(msg("فتح PDF في نافذة منفصلة"),url,'secondary slim','download')}${outside(msg("صفحة الناشر"),x?.url)}<label class="field small">${msg("فتح PDF من جهازك")}<input id="pdf-file" type="file" accept="application/pdf"></label></div>`);
 const node=selector=>modal.querySelector(selector);
 const status=node('#pdf-status'), field=node('#pdf-page'), wrap=node('#pdf-wrap');
 let cancelled=false,task,doc,paint=null,version=0,zoom=1,page=state.reading[id]?.page??1;
 pdfCleanup=()=>{cancelled=true;paint?.cancel();task?.destroy().catch(()=>{});};
 node('#pdf-file').onchange=e=>{if(e.target.files[0])openPdf(id,e.target.files[0]);};
 try{
  const pdf=await import('./vendor/pdf/build/pdf.min.mjs');
  if(cancelled)return;
  pdf.GlobalWorkerOptions.workerSrc=new URL('./vendor/pdf/build/pdf.worker.min.mjs',import.meta.url).href;
  const params=file?{data:new Uint8Array(await file.arrayBuffer())}:{url};
  if(cancelled)return;
  task=pdf.getDocument({...params,standardFontDataUrl:new URL('./vendor/pdf/standard_fonts/',import.meta.url).href,wasmUrl:new URL('./vendor/pdf/wasm/',import.meta.url).href});
  doc=await task.promise;if(cancelled)return;
 }catch{
  if(cancelled)return;
  status.textContent=file?msg("تعذر قراءة الملف المحدد. اختر ملف PDF صالحا."):msg("تعذر وصول القارئ المتقدم إلى ملف الناشر. افتح الملف من المصدر أو اختر نسخته المحمّلة من جهازك.");
  node('.pdf-controls').hidden=true;node('#pdf-search').hidden=true;node('#pdf-marks').hidden=true;
  if(url&&!file){const frame=document.createElement('iframe');frame.title=msg("عرض وثيقة الناشر");frame.src=url;wrap.replaceChildren(frame);}
  return;
 }
 status.textContent='';node('#pdf-count').textContent=' / '+doc.numPages;field.max=doc.numPages;
 async function show(n){
  const current=++version;
  page=Math.min(doc.numPages,Math.max(1,Number(n)||1));field.value=page;
  if(!file){state.reading[id]??={bookmarks:[]};state.reading[id].page=page;save();}
  try{
   paint?.cancel();
   const sheet=await doc.getPage(page);
   if(cancelled||current!==version)return;
   const base=sheet.getViewport({scale:1});
   const view=sheet.getViewport({scale:Math.min(1.25,Math.max(250,wrap.clientWidth-12)/base.width)*zoom});
   const canvas=document.createElement('canvas');canvas.setAttribute('aria-label',msg("صفحة PDF ")+page);
   canvas.width=Math.ceil(view.width*devicePixelRatio);canvas.height=Math.ceil(view.height*devicePixelRatio);
   canvas.style.width=view.width+'px';canvas.style.height=view.height+'px';
   paint=sheet.render({canvas,viewport:view,transform:[devicePixelRatio,0,0,devicePixelRatio,0,0]});
   await paint.promise;if(cancelled||current!==version)return;wrap.replaceChildren(canvas);wrap.scrollTop=0;
  }catch(error){if(!cancelled&&error.name!=='RenderingCancelledException')status.textContent=msg("تعذر رسم الصفحة.");}
 }
 node('#pdf-prev').onclick=()=>show(page-1);
 node('#pdf-next').onclick=()=>show(page+1);
 field.onchange=()=>show(field.value);
 node('#pdf-minus').onclick=()=>{zoom=Math.max(.5,zoom-.25);show(page);};
 node('#pdf-plus').onclick=()=>{zoom=Math.min(3,zoom+.25);show(page);};
 node('#pdf-full').onclick=async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await modal.requestFullscreen();show(page);}catch{toast(msg("ملء الشاشة غير مدعوم هنا."));}};
 let tempBookmarks=[];
 const marks=()=>file?tempBookmarks:state.reading[id]?.bookmarks??[];
 const drawMarks=()=>{const div=node('#pdf-marks div');div.replaceChildren();for(const n of marks())addPdfLink(div,msg("صفحة ")+n,()=>show(n));if(!marks().length)div.textContent=msg("لا توجد علامات.");};
 node('#pdf-bookmark').onclick=()=>{const next=marks().includes(page)?marks().filter(n=>n!==page):[...marks(),page].sort((a,b)=>a-b);if(file)tempBookmarks=next;else{state.reading[id]??={page};state.reading[id].bookmarks=next;save();}drawMarks();};
 drawMarks();
 node('#pdf-search').onsubmit=async event=>{
  event.preventDefault();const query=normalize(new FormData(event.target).get('term'));if(!query)return;
  status.textContent=msg("جار البحث…");
  try{
   for(let j=1;j<=doc.numPages;j++){if(cancelled)return;const n=(page+j-2)%doc.numPages+1;const sheet=await doc.getPage(n),content=await sheet.getTextContent();
    const strings=content.items.map(i=>i.str??'');
    const compact=value=>normalize(value).replaceAll(' ','');
    const reversed=value=>Array.from(value).reverse().join('');
    const text=compact(strings.join(' ')), needle=compact(query);
    if(text.includes(needle)||text.includes(reversed(needle))){status.textContent=msg("وُجدت العبارة في الصفحة ")+n;show(n);return;}
   }
   if(!cancelled)status.textContent=msg("لم توجد العبارة في طبقة النص. قد تكون الصفحات صورا.");
  }catch{if(!cancelled)status.textContent=msg("تعذر البحث في هذه الوثيقة.");}
 };
 show(page);
 doc.getOutline().then(outline=>{
  if(cancelled||!outline?.length)return;
  node('#pdf-outline').hidden=false;
  const append=(items,depth=0)=>items.forEach(item=>{
   if(depth>5)return;
   if(item.dest)addPdfLink(node('#pdf-outline div'),item.title,async()=>{
    try{const dest=typeof item.dest==='string'?await doc.getDestination(item.dest):item.dest;
    if(dest)show(typeof dest[0]==='number'?dest[0]+1:(await doc.getPageIndex(dest[0]))+1);}catch{status.textContent=msg("تعذر فتح عنصر الفهرس.");}
   });
   append(item.items??[],depth+1);
  });
  append(outline);
 }).catch(()=>{});
}
function addPdfLink(node,label,handler){const b=document.createElement('button');b.className='btn secondary slim';b.type='button';b.textContent=label;b.onclick=handler;node.append(b);}


function downloadJSON(value,name){const url=URL.createObjectURL(new Blob([JSON.stringify(value,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),500);}
function render(){
 routeState();applyTheme();applyLanguage();clearInterval(quizTimer);clearInterval(oralTimer);
 const active=state.active;
 if(active?.ends&&active.ends<=Date.now()){finishQuiz();return;}
 const routeNav=links[route]?route:route==='lesson'?byLesson[arg]?.domain:route==='result'?'lab':route==='setup'?'path':'settings';
 document.querySelector('#nav').innerHTML=nav.map(([title,group])=>`<nav class="nav-group" aria-label="${localized(title)}"><span class="nav-label">${localized(title)}</span>${group.map(([id,label,ic])=>`<a class="nav-link" href="#${id}" ${routeNav===id?'aria-current="page"':''}>${icon(ic,17)}${localized(label)}</a>`).join('')}</nav>`).join('');
 document.querySelector('#breadcrumb').innerHTML=`<div class="crumb"><span class="muted">${msg("مساحة المترشح")}</span>${icon('chevron',14)}<strong>${localized(links[routeNav]?.label??"أكاديمية التميز")}</strong></div>`;
 document.querySelector('#topActions').innerHTML=`<select class="language-menu" data-language aria-label="${msg('لغة الواجهة')}">${languageOptions()}</select><span class="muted top-tag">${msg("دورة")} ${localized(cycle()?.title??'')}</span><a href="#notices" class="icon-btn" aria-label="${msg("الإعلانات الرسمية")}">${icon('bell',17)}</a><button class="icon-btn" aria-label="${msg("تبديل الوضع الفاتح والداكن")}" data-action="theme">${icon(state.theme==='dark'?'sun':'moon',17)}</button><a href="#${serverEnabled&&!session?'account':'settings'}" aria-label="${msg("حسابي والإعدادات")}" class="avatar">${esc(state.profile?.name?.[0]??(language==='ar'?'م':'T'))}</a>`;
 const pages={home,setup,path,education:()=>lessonsPage('education'),subject:()=>lessonsPage('subject'),didactics:()=>lessonsPage('didactics'),lesson:()=>lessonPage(arg),library,archive,lab:()=>lab(arg),result:()=>resultPage(arg),errors,oral:oralPage,guide,stats:statsPage,notices,settings,account,admin};
 main.innerHTML=(pages[route]??home)()+`<footer class="legal">${msg("أكاديمية التميز · منصة مستقلة للتحضير لمباراة ولوج سلك تأهيل أطر التدريس")}</footer>`;
 if(route==='library'){
  const form=document.querySelector('#filters');
  if(libraryFilters.level)document.querySelector('#librarySubject').innerHTML=librarySubjects(libraryFilters.level,libraryFilters.subject);
  for(const [name,value] of Object.entries(libraryFilters)){const field=form.elements.namedItem(name);if(field)field.value=value;}
  filterLibrary();
 }
 if(active?.ends){
  const tick=()=>{const left=(active.ends-Date.now())/1000;const clock=document.querySelector('#quiz-clock');if(clock)clock.textContent=clockText(left);if(left<=0){clearInterval(quizTimer);finishQuiz();}};
  tick();quizTimer=setInterval(tick,1000);
 }
 if(route==='oral'&&oralDeadline){
  const tick=()=>{const left=(oralDeadline-Date.now())/1000,clock=document.querySelector('#oral-clock');if(clock)clock.textContent=clockText(left);if(left<=0){oralDeadline=0;clearInterval(oralTimer);if(oralPhase==='answer')stopRecording();toast(msg("انتهى الوقت المحدد."));}};
  tick();oralTimer=setInterval(tick,1000);
 }
}
async function setSession(result, migrateGuest=false){
 const guest=readLocal(storage);
 clearTimeout(syncDelay);syncDelay=null;
 session=result.user;cloudVersion=result.version??0;syncBlocked=false;pendingLocal=false;
 storeKey=session?storage+'-'+session.id:storage;
 const local=readLocal(storeKey);
 let pending;
 try{pending=JSON.parse(localStorage.getItem(storeKey+'-unsynced')||'null');}catch{}
 if(session&&pending?.version===cloudVersion){state=local;}
 else{state=session?(result.state?{...blank(),...result.state}:migrateGuest?guest:local):guest;}
 adminData=null;editRecord=null;
 if(session)save();
 applyTheme();
}
async function actionClick(name,id){
 const a=state.active, q=a?activeQuestion(a,a.ids[a.position]):null;
 switch(name){
 case 'theme': state.theme=state.theme==='dark'?'light':'dark';save();render();return;
 case 'close': closeModal();return;
 case 'rules': state.finished.rules=!state.finished.rules;break;
 case 'final': state.finished.final=!state.finished.final;break;
 case 'favorite':
 case 'queue': {
  if(!bySource[id])return;const key=name==='favorite'?'saved':'queued', had=state[key].includes(id);
  state[key]=had?state[key].filter(x=>x!==id):[...state[key],id];toast(had?msg("أزيل المرجع."):msg("أضيف المرجع."));break;
 }
 case 'source': sourceDetails(id);return;
 case 'pdf': await openPdf(id);return;
 case 'complete': if(!byLesson[id])return;if(state.completed[id])delete state.completed[id];else state.completed[id]=dayKey();break;
 case 'start': startQuiz(id);return;
 case 'discard': openModal(msg("ترك المحاولة"),`<p>${msg("ستحذف الإجابات المحفوظة في هذه المحاولة.")}</p><div class="actions section">${action(msg("اترك المحاولة"),'discard-now','danger')}${action(msg("متابعة"),'close','secondary')}</div>`);return;
 case 'discard-now': state.active=null;closeModal();break;
 case 'question': if(!a||!a.ids[Number(id)])return;a.position=Number(id);break;
 case 'order': if(!q||q.type!=='order'||a.answers[q.id]?.includes(Number(id)))return;a.answers[q.id]=[...(a.answers[q.id]??[]),Number(id)];break;
 case 'order-reset': if(!q)return;delete a.answers[q.id];break;
 case 'finish-confirm': if(!a)return;openModal(msg("تسليم الاختبار"),`<p>${msg("تم حفظ إجابات")} ${fmt(Object.keys(a.answers).length)} ${msg("من")} ${fmt(a.ids.length)} ${msg("أسئلة. يظهر التصحيح بعد التسليم.")}</p><div class="actions section">${action(msg("سلّم الآن"),'finish')}${action(msg("ارجع إلى الأسئلة"),'close','secondary')}</div>`);return;
 case 'finish':finishQuiz();return;
 case 'review-good': case 'review-bad':advanceReview(id,name==='review-good');return;
 case 'oral-clock': oralPhase=id;oralDeadline=Date.now()+(id==='prep'?180:240)*1000;render();return;
 case 'oral-complete': state.oral[id]??={};if(!state.oral[id].complete&&!state.oral[id].text?.trim()&&!audioURL&&!state.oral[id].checks?.length){toast(msg("اكتب جوابا أو أجر تقييما ذاتيا قبل الحفظ."));return;}state.oral[id].complete=!state.oral[id].complete;break;
 case 'record-start':await startRecording();return;
 case 'record-stop':stopRecording();return;
 case 'record-delete':if(audioURL)URL.revokeObjectURL(audioURL);audioURL='';recordedBlob=null;render();return;
 case 'export':downloadJSON(state,'tamayouz-progress.json');return;
 case 'reset':openModal(msg("مسح التقدم المحلي"),`<p>${msg("سيتم مسح خطتك ومحاولاتك المحفوظة على هذا المتصفح.")}</p><div class="actions section">${action(msg("امسح التقدم"),'reset-now','danger')}${action(msg("إلغاء"),'close','secondary')}</div>`);return;
 case 'reset-now':state=blank();closeModal();break;
 case 'logout':await flushSync();await api('/logout',{method:'POST'});await setSession({user:null});go('home');render();return;
 case 'delete-account':openModal(msg("حذف الحساب"),`<form id="deleteAccount" class="form"><p>${msg("سيُحذف الحساب والتقدم على الخادم. يمكنك تصدير نسخة قبل الحذف.")}</p>${field('password',msg("أكد كلمة مرورك"),'password','','required autocomplete="current-password"')}<div class="actions">${submit(msg("احذف حسابي"))}${action(msg("إلغاء"),'close','secondary')}</div></form>`);return;
 case 'admin-refresh':adminData=null;render();return;
 case 'admin-open': {const r=adminData?.entries.find(x=>x.id===id);if(r){editRecord=r;render();document.querySelector('#admin-edit textarea')?.focus();}return;}
 case 'admin-submit': case 'admin-publish': await api('/admin/transition',{method:'POST',body:{id,status:name==='admin-submit'?'review':'published'}});await refreshCatalog();await loadAdmin();toast(msg("حُدثت حالة السجل."));return;
 case 'audit-export':downloadJSON(adminData?.audit??[],'tamayouz-audit.json');return;
 default:return;
 }
 save();render();
}
document.addEventListener('click',async e=>{
 const b=e.target.closest('[data-action]');
 if(!b)return;
 const [name,id]=b.dataset.action.split('/');
 try{await actionClick(name,id);}catch(error){toast(error.message);}
});
document.addEventListener('submit',async e=>{
 const form=e.target;if(!['setup','guide','account','admin-edit','deleteAccount'].includes(form.id)&&!form.classList.contains('role-form'))return;
 e.preventDefault();const p=Object.fromEntries(new FormData(form));
 try {
  if(form.id==='setup'){
   if(!byTrack[p.track])throw Error(msg("اختر تخصصا صالحا."));
   const custom=p.days==='custom';
   const remaining=p.examDate?Math.ceil((Date.parse(p.examDate)-Date.parse(dayKey()))/86400000):0;
   if(custom&&(remaining<1||remaining>180))throw Error(msg("اختر تاريخا بين يوم واحد و180 يوما من اليوم."));
   state.profile={name:p.name.trim(),track:p.track,baseline:p.baseline,minutes:Number(p.minutes),days:custom?remaining:Number(p.days),custom,examDate:p.examDate,preference:p.preference};
   save();go('lab/diagnostic');
  }else if(form.id==='guide'){guideResults(p.query);}
  else if(form.id==='account'){
   const mode=e.submitter?.value??'login';
   const result=await api('/'+mode,{method:'POST',body:p});
   await setSession(result,true);go('home');render();
  }else if(form.id==='admin-edit'){
   let record;try{record=JSON.parse(p.record);}catch{throw Error(msg("أصلح صيغة JSON قبل الحفظ."));}
   await api('/admin/draft',{method:'POST',body:{collection:p.collection,record}});editRecord=null;await loadAdmin();toast(msg("حُفظت المسودة."));
  }else if(form.id==='deleteAccount'){
   await flushSync();await api('/account',{method:'DELETE',body:p});localStorage.removeItem(storeKey);localStorage.removeItem(storeKey+'-unsynced');await setSession({user:null});closeModal();go('home');render();
  }else{
   await api('/admin/role',{method:'POST',body:{id:form.dataset.id,role:p.role}});await loadAdmin();toast(msg("حُفظ الدور."));
  }
 }catch(error){const msg=form.querySelector('#account-message');if(msg)msg.textContent=translate(language,error.message);else toast(error.message);}
});
function changeLanguage(control){
 const next=supportedLanguage(control.value);
 if(next===language)return;
 // Preserve any form that has not yet been submitted.
 const form=main.querySelector('#setup, #account, #admin-edit, #guide');
 const values=form?Object.fromEntries(new FormData(form)):null;
 language=next;
 try{localStorage.setItem(languageStorage,language);}catch{}
 closeModal();
 render();
 if(values){
  const current=document.getElementById(form.id);
  if(form.id==='setup')document.querySelector('#subjectField').innerHTML=trackSelect(values.level,values.track);
  for(const [name,value] of Object.entries(values)){
   const field=current?.elements.namedItem(name);
   if(field)field.value=value;
  }
 }
 const replacement=(control.form?main:document.querySelector('#topActions')).querySelector('select[data-language]');
 replacement?.focus({preventScroll:true});
}
function storeAnswer(value){
 const a=state.active;if(!a)return;const id=a.ids[a.position];
 if(value===''||(Array.isArray(value)&&!value.length))delete a.answers[id];else a.answers[id]=value;
 save();
}
document.addEventListener('input',e=>{
 const el=e.target;
 if(el.form?.id==='filters'&&el.name==='query')filterLibrary();
 if(el.id==='shortAnswer')storeAnswer(el.value);
 if(el.id==='oralAnswer'){state.oral[el.dataset.id]??={};state.oral[el.dataset.id].text=el.value;save();}
});
document.addEventListener('change',e=>{
 const el=e.target;
 if(el.form?.id==='setup'&&el.name==='level')document.querySelector('#subjectField').innerHTML=trackSelect(el.value);
 if(el.form?.id==='filters'){
  if(el.name==='level')document.querySelector('#librarySubject').innerHTML=librarySubjects(el.value);
  filterLibrary();
 }
 if(el.name==='answer'){
  const value=el.type==='checkbox'?[...document.querySelectorAll('input[name=answer]:checked')].map(x=>Number(x.value)):Number(el.value);
  storeAnswer(value);render();const target=[...document.querySelectorAll('input[name=answer]')].find(x=>x.value===el.value);target?.focus({preventScroll:true});
 }
 if(el.id==='oralSelect')go('oral/'+el.value);
 if(el.classList.contains('rubric')){const id=el.dataset.id;state.oral[id]??={};state.oral[id].checks=[...document.querySelectorAll('.rubric:checked')].map(x=>Number(x.value));save();}
 if(el.matches('select[data-language]')){changeLanguage(el);return;}
 if(el.form?.id==='appearance'){state.palette=el.value;save();applyTheme();}
 if(el.id==='admin-copy'&&el.value){const [collection,id]=el.value.split('/');const record=data[collection]?.find(x=>x.id===id);if(record){editRecord={collection,record};render();document.querySelector('#admin-edit textarea')?.focus();}}
});
document.querySelector('.skip').addEventListener('click',event=>{event.preventDefault();main.focus();main.scrollIntoView();});
document.querySelector('#menu').innerHTML=icon('menu');
document.querySelector('#menu').onclick=()=>{showMenu(!mobile);if(mobile)document.querySelector('.nav-link[aria-current], .nav-link')?.focus();};
document.querySelector('#overlay').onclick=()=>{showMenu(false);document.querySelector('#menu').focus();};
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&mobile&&!modal.open){showMenu(false);document.querySelector('#menu').focus();}});
window.addEventListener('hashchange',()=>{
 const prior=route, priorArg=arg;routeState();
 if(prior==='oral'&&(route!=='oral'||arg!==priorArg)){oralDeadline=0;stopRecording();}
 showMenu(false);closeModal();render();window.scrollTo(0,0);main.focus({preventScroll:true});
});
window.addEventListener('online',()=>{if(pendingLocal)flushSync();});
render();
(async()=>{
 try{const result=await api('/session');serverEnabled=true;await setSession(result);await refreshCatalog();render();}catch{}
 if('serviceWorker' in navigator)navigator.serviceWorker.register('./sw.js').catch(()=>{});
})();

