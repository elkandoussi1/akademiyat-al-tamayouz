const cacheName='tamayouz-6';
const shell=['./','./index.html','./app.mjs','./catalog.mjs','./engine.mjs','./i18n.mjs','./style.css','./manifest.webmanifest','./assets/logo.svg','./assets/academy.svg','./assets/icon-192.png','./assets/icon-512.png','./assets/maskable-512.png','./assets/apple-touch-icon.png','./assets/tajawal-regular.woff2','./assets/tajawal-bold.woff2','./guide.pdf'];
self.addEventListener('install',event=>event.waitUntil(caches.open(cacheName).then(cache=>cache.addAll(shell)).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key.startsWith('tamayouz-')&&key!==cacheName).map(key=>caches.delete(key)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{
 const request=event.request,url=new URL(request.url);
 if(request.method!=='GET'||url.origin!==location.origin||url.pathname.includes('/api/'))return;
 if(request.mode==='navigate'){
  event.respondWith(fetch(request).catch(()=>caches.match('./index.html')));return;
 }
 if(!shell.some(path=>new URL(path,self.registration.scope).href===url.href)&&!url.pathname.includes('/vendor/pdf/'))return;
 event.respondWith(fetch(request).then(response=>{
  if(response.ok){const copy=response.clone();caches.open(cacheName).then(cache=>cache.put(request,copy)).catch(()=>{});}
  return response;
 }).catch(()=>caches.match(request)));
});
