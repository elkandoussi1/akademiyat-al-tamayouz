const cacheName='tamayouz-8';
const shell=['./','./index.html','./app.mjs','./catalog.mjs','./engine.mjs','./i18n.mjs','./style.css','./manifest.webmanifest','./assets/logo.svg','./assets/academy.svg','./assets/icon-192.png','./assets/icon-512.png','./assets/maskable-512.png','./assets/apple-touch-icon.png','./assets/tajawal-regular.woff2','./assets/tajawal-bold.woff2','./guide.pdf'];
async function precache(){
 const cache=await caches.open(cacheName);
 await Promise.all(shell.map(async path=>{
  const url=new URL(path,self.registration.scope).href;
  const response=await fetch(url,{cache:'reload'});
  if(!response.ok)throw new Error('precache '+path+' '+response.status);
  await cache.put(url,response);
 }));
}
self.addEventListener('install',event=>event.waitUntil(precache().then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key.startsWith('tamayouz-')&&key!==cacheName).map(key=>caches.delete(key)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{
 const request=event.request,url=new URL(request.url);
 if(request.method!=='GET'||url.origin!==location.origin||url.pathname.includes('/api/'))return;
 if(request.mode==='navigate'){
  event.respondWith(fetch(request,{cache:'no-cache'}).catch(()=>caches.match('./index.html')));return;
 }
 if(!shell.some(path=>new URL(path,self.registration.scope).href===url.href)&&!url.pathname.includes('/vendor/pdf/'))return;
 event.respondWith(fetch(request,{cache:url.pathname.includes('/vendor/pdf/')?'default':'no-cache'}).then(response=>{
  if(response.ok){const copy=response.clone();caches.open(cacheName).then(cache=>cache.put(request,copy)).catch(()=>{});}
  return response;
 }).catch(()=>caches.match(request)));
});
