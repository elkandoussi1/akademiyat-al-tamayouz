export const normalize = value => String(value??'').normalize('NFKC').toLowerCase().replace(/[\u064b-\u065f\u0670ـ]/g,'').replace(/[إأآٱ]/g,'ا').replace(/ى/g,'ي').replace(/[^\p{L}\p{N}\s]/gu,' ').replace(/\s+/g,' ').trim();
export const dayKey = (now=new Date()) => new Intl.DateTimeFormat('sv-SE',{timeZone:'Africa/Casablanca'}).format(now);
export function matchesLesson(lesson, track) {
  return !lesson.subjects?.length || !!track && (lesson.level==='all'||lesson.level===track.level) && lesson.subjects.includes(track.subject);
}
export function correct(question, input) {
  if (question.type==='short') return !!normalize(input)&&question.answer.some(item=>normalize(item)===normalize(input));
  if (question.type==='multi'||question.type==='order') {
    if (!Array.isArray(input)||input.length!==question.answer.length) return false;
    return question.type==='order' ? question.answer.every((item,i)=>item===input[i]) : question.answer.every(item=>input.includes(item));
  }
  return Number.isInteger(input)&&input===question.answer;
}
export function score(questions, answers, lessonIndex) {
  const by={};
  const items=questions.map(question=>{
    const lesson=lessonIndex[question.lesson];
    const domain=lesson?.domain??'education';
    by[domain]??={total:0,correct:0};
    const right=correct(question,answers[question.id]);
    by[domain].total++;
    by[domain].correct+=Number(right);
    return {id:question.id,right,answer:answers[question.id]??null,lesson:question.lesson};
  });
  const right=items.filter(item=>item.right).length;
  return {right,total:items.length,percent:items.length?Math.round(100*right/items.length):0,by,items};
}
export function makePlan(lessons, profile, diagnostic, completed, weights={}, now=dayKey()) {
  const baseline=profile?.baseline==='متقدم'?0.7:profile?.baseline==='مبتدئ'?0.25:0.5;
  const ratio = id => diagnostic?.by[id]?.total ? diagnostic.by[id].correct/diagnostic.by[id].total : baseline;
  const available=lessons.filter(item=>!completed[item.id]);
  const rank = id => (weights[id]??1)*(1.15-ratio(id));
  available.sort((a,b)=>rank(b.domain)-rank(a.domain));
  const budget=Math.max(15,Math.min(480,Number(profile?.minutes)||45));
  const days=Math.max(1,Math.min(180,Number(profile?.days)||30));
  const schedule=[]; let block=0;
  for(const item of available){
    const minutes=item.minutes;
    if(!schedule[block]) schedule[block]={minutes:0,items:[],id:block};
    if(schedule[block].items.length && schedule[block].minutes+minutes>budget && block<days-1) {
      block++;
      schedule[block]={minutes:0,items:[],id:block};
    }
    schedule[block].items.push(item.id);
    schedule[block].minutes+=minutes;
  }
  return schedule.map((slot,i)=>{
    const date=new Date(now+'T12:00:00Z');
    date.setUTCDate(date.getUTCDate()+i);
    return {...slot,date:date.toISOString().slice(0,10),overflow:slot.minutes>budget};
  });
}
export function reviewDate(interval, now=dayKey()) {
  const date=new Date(now+'T12:00:00Z');
  date.setUTCDate(date.getUTCDate()+interval);
  return date.toISOString().slice(0,10);
}
export function readiness({coverage,accuracy,simulation,regularity,mastery}) {
  return Math.round(.25*coverage+.25*accuracy+.2*simulation+.15*regularity+.15*mastery);
}
